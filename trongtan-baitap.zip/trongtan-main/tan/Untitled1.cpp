#include"stdio.h"
int ucln(int a, int b);
{
while(a!=b);
{
	if(a>b) a=a-b;
	else b=b-a;
}
return a;
}
main()
{
int a,b;
scanf("%d%d",a,b);
printf("Uoc chung lon nhat cua 2 so:",ucln(a,b);
} 

