import pandas as pd

s = pd.Series([0,1,2,3])
print(s)

# output
# 0    0
# 1    1
# 2    2
# 3    3
# dtype: int64