import pandas as pd

s = pd.Series([0,1,2,3], index=["a","b","c","d"])
print(s)

# Output:
#
# a    0
# b    1
# c    2
# d    3
# dtype: int64